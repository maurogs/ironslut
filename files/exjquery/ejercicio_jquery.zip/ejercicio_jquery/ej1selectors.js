////////////////////////////////////////////////////////////
//																												//
// EJERCICIO 1: Pon un borde en los siguientes elementos  //
//																												//
////////////////////////////////////////////////////////////

// todos los elementos: ejemplo
$("*").css("border", "solid 1px");

// al div con id "myContent"

// todos los elementos li

// li con la clase "basic"

// el primer elemento li con selectores css

// el segundo elemento li con selectores css

// el último p con selectores css

// al elemento label que tenga un elemento con id "love"

// al elemento li que no tenga la clase "new"

// al elemento a con propiedad href de 'http://www.api.jquery.com/'

// al elemento a con propiedad href que empiece por http://www.

// al elemento a con propiedad href que contenga 'api'

// todos los elementos p

// todos los elementos p dentro del div con clase "myContent"

// Al elemento padre del elemento con id "jquery-ui"

// A los siblings con id "slogan"

// A todos los elementos p que no estén dentro del div "myContent"

// A todos los elementos li que empiecen con jQuery
// mas informacion en http://www.w3schools.com/jsref/jsref_substring.asp
