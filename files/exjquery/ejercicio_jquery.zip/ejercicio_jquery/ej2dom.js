// Cambia el ancho del elemento h1

// Incrementa el tamaño de todo el texto al 120%

// Añade la clase 'ironslut' a todos los elementos con la clase 'new'

// Elimina la clase 'title' del elemento h1

// Pon el rango de edad 'entre 20 y 30' por defecto al cargarse la pagina

// Quitale el 'check' al checkbox de 'Me gusta aprender'

// Elige 'amarillo' como color favorito por defecto al cargar la pagina

// Escribe en el div con id 'result' el nombre por defecto del input (Johnny)

// Escribe en el div con id 'result' la edad seleccionada por defecto (mas de 40)

// Escribe en el div con id 'result' el numero de data likes del li con id 'jquery-ui'

// Suma 100 al numero de data likes del li con id 'jquery-ui' y enseñalo en el div con id 'result'

// Muestra con console.log la posición absoluta del div con id 'result'

// Mueve el div con id 'result' a la posicion 100 top y 150 left

// Cambia el ancho y el alto del div con id 'result' a 300 píxeles

// Añade "(User interface)" después del id "jQueryUI"

// Añade un elemento li con el texto "Future JQ" despues del id "jQueryUI"

// Añade elementos div con la clase bordered alrededor de cada elemento li

// Añade elementos div con la clase bordered alrededor de todos los elementos li

// Elimina el div con id 'result'


//////////////////////
///  Final round   ///
//////////////////////


// En los layers correspondientes a los colores favoritos, cambia el color de
// texto de cada layer estableciendo el color de su value

// Añade links a los elementos li. El link será una url de su nombre con .com

