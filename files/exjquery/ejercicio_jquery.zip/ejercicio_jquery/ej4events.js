// Cuando se cargue la pagina, reemplaza el eslogan por "Piensa menos, escribe mas"

// Eliminar el nombre 'Johnny' al hacer click en el input.

// Al pasar el raton por encima de cualquier proyecto jQuery, el color de fondo se debe cambiar a 'silver'

// Modificar el anterior de tal forma que al alejar el raton de cualquier proyecto jQuery
// se elimine el color de fondo

// Sólo cuando el ratón está encima de un proyecto jQuery, el elemento div con id 'myContent' debe tener
// la clase 'bordered'. Al alejarlo debe dejar de tener esa clase.

// Al terminar de escribir algo en el input, lo escrito debe aparecer en el div con id 'result'

// Al hacer click en cualquier elemento del body, mostrar en el div con id 'result'
// las coordenadas x e y del ratón.

// Al hacer click en el div con id 'result', añade otro div con 'Hola' al final del body.

// Modificar el ejercicio anterior para que se añada el div con 'Hola' únicamente al hacer click
// por primera vez.

// Al hacer click en cualquier proyecto jQuery, añadir un nuevo elemento "jQueryUI"

// Deshabilita las redirecciones de los links a sus respectivos href al hacerles click

// Cuando haces click en un link, que redirija a ironslut.codaffinity.com

// Al seleccionar con el raton parte del texto introducido en el input, se debe mostrar
// la parte seleccionada en el div con id 'result'



//////////////////////
///  Final round   ///
//////////////////////


// Al hacer click en los Proyectos jQuery, duplicarlos

// Al quitarle el check a "Me gusta aprender", mostrar una alerta con "Estás seguro?"

// Al redimensionar la pagina (navegador) mostrar su tamaño en el div con id result

// El div con id 'result' debe seguir al puntero del ratón hasta hacer click.
// El ratón debe estar en el centro del div.


