// Esconde el div con id 'result'

// Esconde el div con id 'result' con un fade de 1 segundo

// Esconde y muestra el div con id 'result' usando slide

// Esconde el div con id 'result' usando slide, espera 1 segundo, y hazle fade

// Crea tu propia velocidad y usala para esconder el div con id 'result'

// Establece la velocidad de animación a 2000 por defecto

// Haz un slide a los 'Proyectos jQuery' y cuando termine que enseñe 'DONE' en el div con id 'result'

// Mueve el div con id 'result' a la esquina inferior izquierda de la pagina.

// Con animación lineal, mueve a la izquierda el div con id 'result' durante 10 segundos, y que luego
// vuelva a su posición inicial
