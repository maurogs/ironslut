$(document).ready(function(){

	// Llamada GET sin parametros aqui:
		$("#get-slutcall").click(function(){

			
			console.log("hola");
		});

	// Llamada GET con parametros:



	// Llamada POST: 



	// Llamada PUT aqui:



	// Llamada DELETE aqui:


});