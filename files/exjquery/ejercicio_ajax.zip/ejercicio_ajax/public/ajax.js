$(document).ready(function(){
	console.log("Starting AJAX exercises");


	// Reemplaza el contenido del div con id 'myContent' con el resultado
	// de una llamada (request) al archivo '/google.html'



	// Reemplaza el contenido del div con id 'result' cuando se haga click en 
	// él con la respuesta de la llamada a /hello:
	// '/hello/' + el contenido del input con id 'name' (como parametro de la llamada)



	// Reemplaza el contenido del div con id 'result' cuando se haga click en él cuando 
	// el usuario modifica el input con id 'amount' o el select con id 'currency'.
	// Para ello hay que hacer una llamada a /exchange con los parametros de amount y currency:
	// /exchange/?amount=100&currency=euro



	// Imprimir en la consola (con console.log()..) el resultado de la llamada a /add con
	// parametros los valores del formulario con id 'personal'.
	// Hay que visualizar en la consola la respuesta AJAX y el codigo status (404, 500...)
	// Para que funcione, hay que hacer una llamada post.







});






